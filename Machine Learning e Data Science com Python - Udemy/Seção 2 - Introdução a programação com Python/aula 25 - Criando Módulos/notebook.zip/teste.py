from my_math import area_quad
from my_math import area_ret
from my_math import peri_quad

print(area_quad(5))
print(area_ret(5, 10))
print(peri_quad(10))