def area_quad(lado):
	return lado * lado

def area_ret(b, h):
	return b * h

def peri_quad(lado):
	return 4 * lado